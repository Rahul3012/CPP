console.log("Hello, JavaScript.");
alert("Hello from JavaScript land.");
